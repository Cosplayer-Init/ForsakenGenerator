#Requires AutoHotkey v2.0
#SingleInstance Force
#Warn
; Forsaken Generator | AutoHotkey v2 | Screen coordinates, 7 x 7 board.
; F3 run, F4 preview, F5 stop, F6/F7 calibrate, F8 background, F9 bind, F10 UI.
CoordMode "Pixel", "Screen"
CoordMode "Mouse", "Screen"
SendMode "Event"
SetMouseDelay -1
SetWinDelay 0

if !IsSet(MACRO_LIBRARY_ONLY) {
    global App := GeneratorApp()
    App.UI.Show(App.S.AutoComplete ? "Hide w820 h738" : "w820 h738 NoActivate")
    OnExit((*) => App.Shutdown())
}

F3::App.Run(true)
F4::App.Run(false)
F5::App.Stop()
F6::App.CaptureCorner(1)
F7::App.CaptureCorner(2)
F8::App.CaptureEmpty()
F9::App.BindTarget()
F10::App.ToggleUI()
#HotIf IsSet(App) && (App.Busy || App.S.AutoScan || App.S.AutoComplete)
Esc::App.Stop()
#HotIf

class GeneratorApp {
    __New(configPath := "") {
        this.ConfigPath := configPath != "" ? configPath : A_ScriptDir "\ForsakenGenerator.ini"
        this.Busy := false, this.Cancelled := false, this.Held := false
        this.TimerPeriod := false, this.Closing := false, this.Target := 0
        this.Grid := [], this.Pairs := [], this.Paths := [], this.Bitmap := 0
        this.CornerA := 0, this.LogLines := [], this.Inputs := Map(), this.Frame := 0
        this.CaptureFailed := false, this.CaptureSource := 0, this.ActiveInput := "Input", this.StartPoint := 0
        this.Calibrating := false, this.AutoReading := false, this.PendingSettle := 70
        this.WaitHandle := 0, this.PreciseWaitUnavailable := false
        this.Pages := [[], [], []], this.ButtonStyles := Map(), this.Nav := []
        this.S := this.Defaults()
        this.LoadSettings()
        this.MakeUI()
        this.Watcher := PuzzleWatcher(this)
        this.Watcher.Start()
    }

    Defaults() {
        return {X: "738,811,883,959,1031,1108,1184", Y: "292,366,439,513,587,660,733",
            Empty: "0A0A0A", Segment: 44, Press: 100, Release: 45, Settle: 70,
            Verify: 150, Retries: 4, ScanTol: 24, WireTol: 60, Radius: 3,
            Dark: 35, Frames: 2, Timeout: 12, Delay: 140, Fill: 0, Top: 1,
            ReturnUI: 1, Capture: "Normal", Input: "Input", Lightning: 0,
            AutoScan: 0, AutoComplete: 0, Version: 2}
    }

    LoadSettings() {
        previousVersion := 0
        try previousVersion := Integer(IniRead(this.ConfigPath, "Settings", "Version", 0))
        for name, default in this.S.OwnProps() {
            try this.S.%name% := IniRead(this.ConfigPath, "Settings", name, default)
        }
        if previousVersion < 2 {
            ; Upgrade old timing defaults while preserving coordinates and scan calibration.
            for index, oldTiming in [[38,65,45,160], [26,55,40,130], [65,95,65,230]] {
                if this.S.Segment = oldTiming[1] && this.S.Press = oldTiming[2] && this.S.Release = oldTiming[3] && this.S.Verify = oldTiming[4] {
                    timing := [[44,100,45,150], [34,90,40,130], [65,140,65,240]][index]
                    this.S.Segment := timing[1], this.S.Press := timing[2], this.S.Release := timing[3], this.S.Verify := timing[4]
                    break
                }
            }
            for key, oldValue in Map("Segment", 38, "Press", 65, "Settle", 45, "Verify", 160, "Delay", 350)
                if this.S.%key% = oldValue
                    this.S.%key% := this.Defaults().%key%
            this.S.Press := Max(70, Integer(this.S.Press))
            this.S.Segment := Max(30, Integer(this.S.Segment))
            this.S.Version := 2
        }
        ; Reject an invalid configuration as a whole instead of running bad coordinates.
        try this.Validate(this.S)
        catch
            this.S := this.Defaults()
    }

    MakeUI() {
        ui := this.UI := Gui("+AlwaysOnTop", "Forsaken Generator")
        ui.BackColor := "10151F"
        darkTitle := Buffer(4), NumPut("Int", 1, darkTitle)
        try DllCall("dwmapi\DwmSetWindowAttribute", "Ptr", ui.Hwnd, "UInt", 20, "Ptr", darkTitle, "UInt", 4)
        ui.SetFont("s10 cDCE5F3", "Segoe UI")
        ui.OnEvent("Close", (*) => this.Close())
        ui.OnEvent("Escape", (*) => (this.Busy || this.S.AutoScan || this.S.AutoComplete) ? this.Stop() : this.UI.Hide())
        ; Native buttons with owner drawing retain keyboard focus and accessibility.
        this.DrawHandler := ObjBindMethod(this, "DrawButton")
        OnMessage(0x2B, this.DrawHandler)
        ui.SetFont("s21 Bold cF3F6FC")
        ui.AddText("x28 y20 w620 h36", "FORSAKEN / GENERATOR")
        ui.SetFont("s10 Norm c8D9AB0")
        ui.AddText("x30 y61 w640 h22", "Fast scans. Steady clicks. Checked paths.")
        this.Badge := ui.AddText("x678 y33 w110 h28 Center +0x200 c73E0CB Background1B2B32", "READY")
        labels := ["&Main", "Scan &Graph", "&Settings"]
        Loop 3 {
            n := A_Index
            btn := this.Button(labels[n], 28 + (n - 1) * 162, 101, 152, 38,
                ObjBindMethod(this, "SelectPage", n), "nav")
            this.Nav.Push(btn)
        }
        ui.AddProgress("x28 y145 w764 h1 c263247 Background263247", 100)

        this.Page := 1
        this.Panel(28, 168, 764, 132)
        this.Label("WORKSPACE", 48, 185, 600, 18, "s9 Bold c75DFCB")
        this.StateText := this.Label("Ready when you are", 48, 213, 690, 35, "s20 Bold cF3F6FC")
        this.Detail := this.Label("Open a fresh puzzle, then press F3. Use F4 to inspect before clicking.", 48, 262, 708, 22)
        for item in [["PAIRS", "0", 28], ["CHECKED PATHS", "0 / 0", 288], ["RUN TIME", "—", 548]] {
            this.Panel(item[3], 316, 244, 82)
            this.Label(item[1], item[3] + 18, 329, 210, 18, "s9 Bold c8D9AB0")
            metric := this.Label(item[2], item[3] + 18, 351, 210, 30, "s19 Bold cF3F6FC")
            if item[1] = "PAIRS"
                this.PairMetric := metric
            else if item[1] = "CHECKED PATHS"
                this.PathMetric := metric
            else
                this.TimeMetric := metric
        }
        this.RunBtn := this.PageButton("Scan && solve   F3", 28, 420, 286, 48, (*) => this.Run(true), "accent")
        this.PreviewBtn := this.PageButton("Preview   F4", 326, 420, 228, 48, (*) => this.Run(false))
        this.StopBtn := this.PageButton("Stop   F5", 566, 420, 226, 48, (*) => this.Stop(), "danger")
        this.Panel(28, 484, 764, 56)
        this.Inputs["AutoScan"] := this.Add("Checkbox", "x46 y499 w180 h25 -Theme cDCE5F3", "Auto scan to graph")
        this.Inputs["AutoComplete"] := this.Add("Checkbox", "x250 y499 w190 h25 -Theme cDCE5F3", "Auto complete")
        for key in ["AutoScan", "AutoComplete"]
            this.Inputs[key].OnEvent("Click", (*) => this.ApplyAutomation())
        this.AutoLabel := this.Label("OFF / checks every second", 460, 502, 310, 23, "s9 c8D9AB0")
        this.Label("ACTIVITY", 30, 554, 600, 20, "s9 Bold c8D9AB0")
        this.LogCtrl := this.Add("Edit", "x28 y580 w764 h90 ReadOnly -Wrap -VScroll cB5C4D9 Background19212E", "Waiting for a fresh 7 × 7 puzzle.")
        this.Label("F3  Run    F4  Preview    F5 / Esc  Stop + turn off auto    F10  Show / hide", 30, 699, 760, 22, "s9 c8D9AB0")

        this.Page := 2
        this.Label("SCAN GRAPH", 30, 169, 700, 26, "s16 Bold cF3F6FC")
        this.Label("Endpoints and planned paths from your most recent scan.", 30, 204, 740, 21)
        this.Graph := this.Add("Picture", "x28 y245 w434 h434", "")
        this.Panel(482, 245, 310, 350)
        this.Label("CONNECTIONS", 502, 265, 270, 19, "s9 Bold c75DFCB")
        this.UI.SetFont("s9")
        this.Legend := this.Add("Edit", "x502 y298 w268 h234 ReadOnly -Wrap -VScroll -E0x200 cB5C4D9 Background19212E", "No scan yet.`r`n`r`nF4 creates a preview without`r`npressing the mouse button.")
        this.UI.SetFont("s10")
        this.GraphInfo := this.Label("7 × 7 grid / 49 cells", 502, 548, 268, 22)
        this.PageButton("Scan preview   F4", 482, 613, 310, 46, (*) => this.Run(false), "accent")
        this.Label("Numbers label color pairs. Lines show the calculated route.", 30, 699, 750, 20, "s9 c8D9AB0")

        this.Page := 3
        this.Label("SETTINGS", 30, 167, 700, 25, "s16 Bold cF3F6FC")
        this.Label("Save to apply. Lightning Fast targets ~2 s and skips per-path drag checks.", 30, 202, 750, 20)
        this.Panel(28, 239, 370, 409)
        this.Panel(414, 239, 378, 409)
        this.Label("SPEED & RECOVERY", 46, 253, 340, 20, "s9 Bold c75DFCB")
        this.Label("Preset", 46, 288, 166, 23)
        this.Preset := this.Add("DropDownList", "x221 y284 w159 Choose1", ["Balanced", "Fast", "Careful", "Lightning Fast", "Custom"])
        this.Preset.OnEvent("Change", (*) => this.ApplyPreset())
        this.Field("Segment", "Drag per cell", 46, 324, 221)
        this.Field("Press", "Mouse-down hold", 46, 358, 221)
        this.Field("Release", "End hold", 46, 392, 221)
        this.Field("Verify", "Line-check timeout", 46, 426, 221)
        this.Field("Retries", "Attempts per path", 46, 460, 221)
        this.Field("Timeout", "Solver limit (seconds)", 46, 494, 221)
        this.Field("Delay", "Start delay", 46, 528, 221)
        this.Label("Mouse input", 46, 566, 166, 22)
        this.Inputs["Input"] := this.Add("DropDownList", "x221 y563 w159", ["Input", "Event"])
        this.Toggle("Fill", "Require every cell filled", 46, 597)
        this.Toggle("Top", "Keep window on top", 46, 625)
        this.Label("SCAN & CALIBRATION", 432, 253, 340, 20, "s9 Bold c75DFCB")
        this.Field("ScanTol", "Endpoint color tolerance", 432, 287, 640, 132)
        this.Field("WireTol", "Line hue tolerance", 432, 321, 640, 132)
        this.Field("Radius", "Sample radius (pixels)", 432, 355, 640, 132)
        this.Field("Dark", "Empty brightness ceiling", 432, 389, 640, 132)
        this.Field("Frames", "Stable scan frames", 432, 423, 640, 132)
        this.Label("Pixel capture", 432, 460, 190, 23)
        this.Inputs["Capture"] := this.Add("DropDownList", "x640 y456 w132", ["Normal", "Alt", "Slow"])
        this.Label("Empty RGB", 432, 492, 190, 23)
        this.Inputs["Empty"] := this.Add("Edit", "x640 y489 w132 h26 cE4EAF5 Background263247", this.S.Empty)
        this.PageButton("Calibrate grid", 432, 529, 162, 35, (*) => this.BeginCalibration())
        this.PageButton("Bind game   F9", 604, 529, 168, 35, (*) => this.BindInstructions())
        this.Toggle("ReturnUI", "Show window after run", 432, 583)
        this.Label("F6  First center   F7  Last center   F8  Empty color", 432, 618, 348, 18, "s8 c8D9AB0")
        this.Label("Column centers (screen X)", 30, 659, 180, 18, "s8 c8D9AB0")
        this.Inputs["X"] := this.Add("Edit", "x211 y654 w346 h25 cE4EAF5 Background263247", this.S.X)
        this.Label("Row centers (screen Y)", 30, 693, 180, 18, "s8 c8D9AB0")
        this.Inputs["Y"] := this.Add("Edit", "x211 y688 w346 h25 cE4EAF5 Background263247", this.S.Y)
        this.PageButton("Save settings", 577, 654, 215, 34, (*) => this.SaveSettings(), "accent")
        this.PageButton("Restore defaults", 577, 694, 215, 30, (*) => this.RestoreDefaults())
        this.Page := 0
        this.SyncSettings()
        this.DrawGraph()
        this.SelectPage(1)
        if !this.S.Top
            ui.Opt("-AlwaysOnTop")
    }

    Add(kind, options, text := "") {
        ctrl := this.UI.Add(kind, options, text)
        if this.Page
            this.Pages[this.Page].Push(ctrl)
        return ctrl
    }
    Label(text, x, y, w, h, font := "s10 Norm c8D9AB0") {
        this.UI.SetFont(font)
        ctrl := this.Add("Text", "x" x " y" y " w" w " h" h " BackgroundTrans", text)
        this.UI.SetFont("s10 Norm cDCE5F3")
        return ctrl
    }
    Panel(x, y, w, h) => this.Add("Text", "x" x " y" y " w" w " h" h " Background19212E", "")
    Button(text, x, y, w, h, callback, style := "normal") {
        ctrl := this.UI.AddButton("x" x " y" y " w" w " h" h " -Theme", text)
        ctrl.OnEvent("Click", callback)
        styleBits := (ControlGetStyle(ctrl) & ~0xF) | 0xB
        DllCall(A_PtrSize = 8 ? "SetWindowLongPtrW" : "SetWindowLongW", "Ptr", ctrl.Hwnd, "Int", -16, "Ptr", styleBits, "Ptr")
        this.ButtonStyles[ctrl.Hwnd] := {kind: style, active: false}
        return ctrl
    }
    PageButton(text, x, y, w, h, callback, style := "normal") {
        ctrl := this.Button(text, x, y, w, h, callback, style)
        this.Pages[this.Page].Push(ctrl)
        return ctrl
    }
    Field(key, label, x, y, ex, width := 159) {
        this.Label(label, x, y + 4, ex - x - 6, 22)
        this.Inputs[key] := this.Add("Edit", "x" ex " y" y " w" width " h26 Number cE4EAF5 Background263247", this.S.%key%)
    }
    Toggle(key, label, x, y) {
        this.Inputs[key] := this.Add("Checkbox", "x" x " y" y " w330 h23 -Theme cC2CEDF", label)
        this.Inputs[key].Value := this.S.%key%
    }
    SelectPage(n, *) {
        Loop 3 {
            pageIndex := A_Index
            for ctrl in this.Pages[pageIndex]
                ctrl.Visible := pageIndex = n
            this.ButtonStyles[this.Nav[pageIndex].Hwnd].active := pageIndex = n
            DllCall("InvalidateRect", "Ptr", this.Nav[pageIndex].Hwnd, "Ptr", 0, "Int", true)
        }
    }

    DrawButton(wParam, lParam, msg, hwnd) {
        handleOffset := A_PtrSize = 8 ? 24 : 20
        ctl := NumGet(lParam, handleOffset, "Ptr")
        if !this.ButtonStyles.Has(ctl)
            return
        dc := NumGet(lParam, handleOffset + A_PtrSize, "Ptr")
        rect := lParam + handleOffset + 2 * A_PtrSize
        state := NumGet(lParam, 16, "UInt")
        style := this.ButtonStyles[ctl]
        bg := style.kind = "accent" ? 0x75DFCB : style.kind = "danger" ? 0x34222D
            : (style.kind = "nav" && style.active) ? 0x263C45 : 0x263247
        fg := style.kind = "accent" ? 0x102323 : style.kind = "danger" ? 0xFF9FAE
            : (style.kind = "nav" && style.active) ? 0x93F0DA : 0xDCE5F3
        if state & 4
            fg := 0x77859B, bg := 0x202938
        if state & 1
            bg := 0x3A5264
        brush := DllCall("gdi32\CreateSolidBrush", "UInt", RGBToBGR(bg), "Ptr")
        DllCall("FillRect", "Ptr", dc, "Ptr", rect, "Ptr", brush)
        DllCall("gdi32\DeleteObject", "Ptr", brush)
        DllCall("gdi32\SetBkMode", "Ptr", dc, "Int", 1)
        DllCall("gdi32\SetTextColor", "Ptr", dc, "UInt", RGBToBGR(fg))
        font := SendMessage(0x31, 0, 0, ctl)
        oldFont := DllCall("gdi32\SelectObject", "Ptr", dc, "Ptr", font, "Ptr")
        DllCall("DrawTextW", "Ptr", dc, "Str", ControlGetText(ctl), "Int", -1, "Ptr", rect, "UInt", 0x25)
        if (state & 0x10) && !(state & 0x200)
            DllCall("DrawFocusRect", "Ptr", dc, "Ptr", rect)
        DllCall("gdi32\SelectObject", "Ptr", dc, "Ptr", oldFont)
        return true
    }

    SyncSettings() {
        for key, ctrl in this.Inputs {
            if key = "Capture" || key = "Input"
                ctrl.Choose(this.S.%key%)
            else
                ctrl.Value := this.S.%key%
        }
        this.Preset.Choose(this.SpeedPreset(this.S))
        this.PendingSettle := this.S.Settle
    }
    SpeedPreset(s) {
        if s.Lightning
            return 4
        for index, values in [[44, 100, 45, 150], [34, 90, 40, 130], [65, 140, 65, 240]]
            if s.Segment = values[1] && s.Press = values[2] && s.Release = values[3] && s.Verify = values[4]
                return index
        return 5
    }
    ApplyPreset() {
        if this.Busy
            return
        if this.Preset.Value = 5 {
            this.PendingSettle := 70
            return
        }
        if this.Preset.Value = 4 {
            for key, value in Map("Segment", 12, "Press", 20, "Release", 8, "Verify", 0, "Retries", 1, "Frames", 1, "Delay", 0)
                this.Inputs[key].Value := value
            this.Inputs["Input"].Choose("Input")
            this.Inputs["Capture"].Choose("Normal")
            this.PendingSettle := 10
            return
        }
        data := this.Preset.Value = 2 ? [34, 90, 40, 130] : this.Preset.Value = 3 ? [65, 140, 65, 240] : [44, 100, 45, 150]
        for i, key in ["Segment", "Press", "Release", "Verify"]
            this.Inputs[key].Value := data[i]
        this.PendingSettle := 70
        frames := this.Inputs["Frames"].Value, delay := this.Inputs["Delay"].Value
        this.Inputs["Frames"].Value := IsInteger(frames) ? Max(2, Integer(frames)) : 2
        this.Inputs["Delay"].Value := IsInteger(delay) ? Max(140, Integer(delay)) : 140
        if this.Inputs["Retries"].Value = 1
            this.Inputs["Retries"].Value := 4
    }
    Validate(s) {
        ParseAxis(s.X), ParseAxis(s.Y)
        if !RegExMatch(s.Empty, "i)^[0-9a-f]{6}$")
            throw Error("Empty RGB must have exactly six hexadecimal digits.")
        limits := Map("Segment", [30, 180], "Press", [70, 250], "Release", [25, 250],
            "Verify", [80, 600], "Retries", [1, 6], "ScanTol", [5, 70], "WireTol", [20, 100],
            "Radius", [1, 8], "Dark", [10, 80], "Frames", [2, 4], "Timeout", [1, 30],
            "Delay", [100, 3000], "Settle", [25, 250])
        if s.Lightning {
            ; This preset deliberately bypasses the ordinary timing floors.
            for key, minimum in Map("Segment", 1, "Press", 1, "Release", 0, "Verify", 0, "Frames", 1, "Delay", 0, "Settle", 0)
                limits[key][1] := minimum
        }
        for key, range in limits {
            value := s.%key%
            if !IsInteger(value) || value < range[1] || value > range[2]
                throw Error(key " must be an integer from " range[1] " to " range[2] ".")
            s.%key% := Integer(value)
        }
        for key in ["Fill", "Top", "ReturnUI", "Lightning", "AutoScan", "AutoComplete"] {
            if s.%key% != 0 && s.%key% != 1
                throw Error("Invalid toggle: " key)
            s.%key% := Integer(s.%key%)
        }
        if s.Capture != "Normal" && s.Capture != "Alt" && s.Capture != "Slow"
            throw Error("Choose Normal, Alt, or Slow pixel capture.")
        if s.Input != "Input" && s.Input != "Event"
            throw Error("Choose Input or Event mouse input.")
        return s
    }
    SaveSettings(*) {
        if this.Busy
            return
        try {
            next := this.S.Clone()
            for key, ctrl in this.Inputs
                next.%key% := (key = "Capture" || key = "Input") ? ctrl.Text : ctrl.Value
            next.Lightning := this.Preset.Value = 4 ? 1 : 0
            next.Settle := this.PendingSettle
            this.Validate(next)
            this.Persist(next)
            this.S := next
            this.Preset.Choose(this.SpeedPreset(next))
            this.UI.Opt(next.Top ? "+AlwaysOnTop" : "-AlwaysOnTop")
            this.Watcher.Start()
            this.Log(next.Lightning ? "Lightning Fast saved: direct transfers, one pass, checks after drawing." : "Settings saved. " next.Segment " ms per cell, with automatic slower retries.")
            this.State("Settings saved", "Return to Main or Scan Graph when the puzzle is ready.")
            if next.AutoComplete
                this.UI.Hide()
        } catch as e
            MsgBox(e.Message, "Check settings", "Icon!")
    }
    Persist(s) {
        for key, value in s.OwnProps()
            IniWrite(value, this.ConfigPath, "Settings", key)
    }
    ApplyAutomation(*) {
        if this.Busy
            return
        try {
            next := this.S.Clone()
            next.AutoScan := this.Inputs["AutoScan"].Value
            next.AutoComplete := this.Inputs["AutoComplete"].Value
            this.Persist(next)
            newlyScanning := next.AutoScan && !this.S.AutoScan
            newlyCompleting := next.AutoComplete && !this.S.AutoComplete
            this.S := next
            if newlyScanning
                this.Watcher.LastPresented := 0
            this.Watcher.Start()
            this.Log("Automatic options saved: scan " (next.AutoScan ? "on" : "off") ", complete " (next.AutoComplete ? "on" : "off") ".")
            if newlyCompleting
                this.UI.Hide()
        } catch as e {
            this.Inputs["AutoScan"].Value := this.S.AutoScan
            this.Inputs["AutoComplete"].Value := this.S.AutoComplete
            this.Log("Automatic options could not be saved: " e.Message)
        }
    }
    AutoStatus(message) {
        this.AutoMessage := message
        if InStr(message, "stopped")
            compact := "OFF / checks every second"
        else if InStr(message, "Completing")
            compact := "Puzzle detected / completing"
        else if InStr(message, "Focus")
            compact := "Paused / focus the game"
        else if InStr(message, "obscured")
            compact := "Paused / keep the board visible"
        else if InStr(message, "Calibrate")
            compact := "Paused / calibrate and bind game"
        else if InStr(message, "up to date")
            compact := "Auto scan / graph up to date"
        else if InStr(message, "new puzzle")
            compact := "Waiting for a new puzzle"
        else
            compact := "Watching / checks every second"
        this.AutoLabel.Text := compact
    }
    AutoFocusAllowed() {
        active := WinExist("A")
        return active && (active = this.Target || active = this.UI.Hwnd)
    }
    CanAutoPoll() {
        if this.Busy || this.Calibrating || this.AutoReading
            return false
        try {
            this.X := ParseAxis(this.S.X), this.Y := ParseAxis(this.S.Y)
            if !this.Target || !WinExist("ahk_id " this.Target) {
                candidate := WindowAt(this.X[4], this.Y[4])
                if !candidate || candidate = this.UI.Hwnd {
                    this.Watcher.Status("Calibrate the grid and bind the game with F9.")
                    return false
                }
                this.Target := candidate
                this.CaptureFailed := false, this.CaptureSource := 0
            }
            if !this.AutoFocusAllowed() {
                this.Watcher.Status("Focus the game to resume automatic scanning.")
                return false
            }
            WinGetPos(&x, &y, &w, &h, "ahk_id " this.Target)
            this.Bounds := {x: x, y: y, w: w, h: h}
            if !this.BoardInWindow() {
                this.Watcher.Status("Calibrate the grid and bind the game with F9.")
                return false
            }
            ; Pausing on obstruction does not rearm an already attempted puzzle.
            ; Read-only polling never hides the panel or focuses the game.
            for sy in this.Y
                for sx in this.X
                    if WindowAt(sx, sy) != this.Target {
                        this.Watcher.Status("Board obscured. Move the panel away from the puzzle.")
                        return false
                    }
            return true
        } catch {
            this.Watcher.Status("Calibrate the grid and bind the game with F9.")
            return false
        }
    }
    CanAutoComplete(scan) => !GetKeyState("LButton", "P") && WinActive("ahk_id " this.Target)
    ReadAutoBoard() {
        if !this.CanAutoPoll()
            return 0
        this.AutoReading := true
        try return this.ScanStable(2)
        finally {
            this.EndFrame()
            this.AutoReading := false
        }
    }
    ShowAutoBoard(scan) {
        this.Grid := scan.grid, this.Pairs := scan.pairs, this.Paths := []
        this.PairMetric.Text := this.Pairs.Length
        this.PathMetric.Text := "0 / " this.Pairs.Length
        this.DrawGraph()
        this.State("Puzzle scanned automatically", "Live endpoints are ready in Scan Graph. Auto complete runs when the game is focused.", "SCANNED")
    }
    RestoreDefaults(*) {
        if this.Busy
            return
        this.S := this.Defaults()
        this.SyncSettings()
        this.Preset.Choose(1)
        this.SaveSettings()
    }

    BeginCalibration() {
        if this.Busy
            return
        this.CornerA := 0
        this.Calibrating := true
        this.UI.Hide()
        ToolTip("Hover the top-left CELL CENTER and press F6.`nThen hover the bottom-right CELL CENTER and press F7.")
    }
    CaptureCorner(which) {
        if this.Busy
            return
        MouseGetPos(&x, &y)
        if which = 1 {
            this.Calibrating := true
            this.CornerA := {x: x, y: y}
            ToolTip("First center captured. Hover the bottom-right CELL CENTER and press F7.")
            return
        }
        if !IsObject(this.CornerA) {
            this.Notify("Capture the top-left center with F6 first.")
            return
        }
        if x - this.CornerA.x < 120 || y - this.CornerA.y < 120 {
            this.Notify("The last center must be below and to the right of the first center.")
            return
        }
        xs := [], ys := []
        Loop 7 {
            xs.Push(Round(this.CornerA.x + (A_Index - 1) * (x - this.CornerA.x) / 6))
            ys.Push(Round(this.CornerA.y + (A_Index - 1) * (y - this.CornerA.y) / 6))
        }
        this.S.X := Join(xs), this.S.Y := Join(ys)
        this.Inputs["X"].Value := this.S.X, this.Inputs["Y"].Value := this.S.Y
        this.CornerA := 0
        this.Calibrating := false
        try this.Persist(this.S)
        catch as e {
            this.Notify("Calibration applied for this session; saving failed: " e.Message)
            return
        }
        ToolTip()
        this.UI.Show("NoActivate")
        this.Log("Grid calibrated and saved. Keep the game at the same size and position.")
    }
    CaptureEmpty() {
        if this.Busy
            return
        MouseGetPos(&x, &y)
        try {
            hex := Format("{:06X}", this.ReadPixel(x, y))
            this.S.Empty := hex, this.Inputs["Empty"].Value := hex
            this.Persist(this.S)
            this.Notify("Empty color saved: #" hex)
        } catch as e
            this.Notify(e.Message)
    }
    BindInstructions() {
        if this.Busy
            return
        this.UI.Hide()
        this.Calibrating := true
        this.Notify("Activate the game, then press F9 to bind its window.")
    }
    BindTarget() {
        if this.Busy
            return
        hwnd := WinExist("A")
        if hwnd = this.UI.Hwnd {
            this.BindInstructions()
            return
        }
        this.Target := hwnd
        this.CaptureFailed := false, this.CaptureSource := 0, this.Calibrating := false
        this.Notify("Game window bound: " WinGetTitle("ahk_id " hwnd))
        this.Log("Target bound. F3 runs; F4 previews; F10 shows the window.")
    }
    ToggleUI() {
        if this.Busy
            return
        if DllCall("IsWindowVisible", "Ptr", this.UI.Hwnd)
            this.UI.Hide()
        else
            this.UI.Show("NoActivate")
    }
    Notify(text) {
        ToolTip(text)
        SetTimer(() => ToolTip(), -4200)
    }
    Log(message) {
        this.LogLines.Push(FormatTime(, "HH:mm:ss") "  " message)
        if this.LogLines.Length > 80
            this.LogLines.RemoveAt(1)
        this.LogCtrl.Value := Join(this.LogLines, "`r`n")
        SendMessage(0x115, 7, 0, this.LogCtrl)
    }
    State(title, detail, badge := "READY") {
        this.StateText.Text := title, this.Detail.Text := detail, this.Badge.Text := badge
    }
    Stop(*) {
        this.S.AutoScan := 0, this.S.AutoComplete := 0
        this.Inputs["AutoScan"].Value := 0, this.Inputs["AutoComplete"].Value := 0
        this.Watcher.Stop()
        this.Calibrating := false
        ToolTip()
        try this.Persist(this.S)
        if this.Busy {
            this.Cancelled := true
            this.ReleaseMouse()
        }
    }
    Close() {
        this.Watcher.Stop()
        if this.Busy {
            this.Closing := true
            this.Stop()
            this.UI.Hide()
        } else
            ExitApp()
    }
    Cleanup() {
        this.ReleaseMouse()
        this.EndFrame()
        if this.WaitHandle {
            DllCall("CloseHandle", "Ptr", this.WaitHandle)
            this.WaitHandle := 0
        }
        if this.TimerPeriod {
            DllCall("winmm\timeEndPeriod", "UInt", 1)
            this.TimerPeriod := false
        }
    }
    Shutdown() {
        this.Watcher.Stop()
        this.Cleanup()
    }
    ReleaseMouse() {
        if this.Held {
            if this.ActiveInput = "Input"
                SendInput("{Blind}{LButton up}")
            else
                SendEvent("{Blind}{LButton up}")
            this.Held := false
        }
    }
    MoveMouse(x, y) => MouseMove(x, y, 0)
    CursorPosition() {
        MouseGetPos(&x, &y)
        return {x: x, y: y}
    }
    TweenMouse(x, y, duration := 0) {
        this.Check()
        start := this.CursorPosition()
        dx := x - start.x, dy := y - start.y
        if dx = 0 && dy = 0
            return
        if duration <= 0
            duration := this.S.Lightning ? Round(Max(20, Min(60, 15 + Sqrt(dx * dx + dy * dy) / 15)))
                : Round(Max(100, Min(260, 80 + Sqrt(dx * dx + dy * dy) / 3)))
        began := MonotonicMs()
        ; Small timed movements with eased acceleration/deceleration retain stop/focus checks.
        loop {
            this.Check()
            elapsed := MonotonicMs() - began
            if elapsed >= duration
                break
            t := elapsed / duration
            eased := t * t * (3 - 2 * t)
            this.MoveMouse(Round(start.x + dx * eased), Round(start.y + dy * eased))
            this.Wait(Min(8, Max(1, duration - elapsed)))
        }
        this.Check()
        this.MoveMouse(x, y)
    }
    PressMouse() {
        this.Check()
        point := this.StartPoint
        if !IsObject(point)
            throw Error("Starting point is not set.")
        this.EnsureCursor(point.x, point.y)
        this.Held := true
        ; Couple the down event to explicit coordinates instead of a free-floating Click Down.
        clickEvent := "{Blind}{Click " point.x " " point.y " Left Down}"
        if this.ActiveInput = "Input"
            SendInput(clickEvent)
        else
            SendEvent(clickEvent)
    }
    EnsureCursor(x, y) {
        Loop 3 {
            actual := this.CursorPosition()
            if Abs(actual.x - x) <= 2 && Abs(actual.y - y) <= 2
                return
            if A_Index < 3 {
                this.TweenMouse(x, y, 50)
                this.Wait(25)
            }
        }
        throw Error("Cursor could not stay on the starting dot. Release the mouse and try again.")
    }
    Check() {
        if this.AutoReading {
            if !this.Watcher.Running || this.Calibrating || this.Busy || !this.AutoFocusAllowed()
                throw Error("Automatic scan paused.")
        } else {
        if this.Cancelled
            throw Error("Stopped. Mouse button released.")
        if !WinActive("ahk_id " this.Target)
            throw Error("Game lost focus. Stopped to avoid clicking another window.")
        }
        WinGetPos(&x, &y, &w, &h, "ahk_id " this.Target)
        b := this.Bounds
        if x != b.x || y != b.y || w != b.w || h != b.h
            throw Error("Game moved or resized. Recalibrate before running again.")
    }
    Wait(ms) {
        deadline := MonotonicMs() + ms
        while MonotonicMs() < deadline {
            this.Check()
            this.PauseSlice(Min(8, Max(0.1, deadline - MonotonicMs())))
        }
        this.Check()
    }
    PauseSlice(ms) {
        ; Ordinary Sleep can round short waits to a full scheduler tick. The
        ; aggressive preset uses a high-resolution timer, with a safe fallback.
        if this.S.Lightning && !this.PreciseWaitUnavailable {
            if !this.WaitHandle {
                try this.WaitHandle := DllCall("CreateWaitableTimerExW", "Ptr", 0, "Ptr", 0,
                    "UInt", 2, "UInt", 0x100002, "Ptr")
                if !this.WaitHandle
                    this.PreciseWaitUnavailable := true
            }
            if this.WaitHandle {
                due := -Max(1, Round(ms * 10000))
                if DllCall("SetWaitableTimer", "Ptr", this.WaitHandle, "Int64*", &due,
                    "Int", 0, "Ptr", 0, "Ptr", 0, "Int", false)
                    && DllCall("WaitForSingleObject", "Ptr", this.WaitHandle, "UInt", 25, "UInt") = 0 {
                    Sleep(-1)
                    return
                }
                this.PreciseWaitUnavailable := true
            }
        }
        Sleep(Max(1, Ceil(ms)))
    }

    Run(execute := true, suppliedScan := 0, automatic := false) {
        if this.Busy || this.AutoReading
            return
        this.Busy := true, this.Cancelled := false, this.CaptureFailed := false, this.CaptureSource := 0
        this.Grid := [], this.Pairs := [], this.Paths := []
        this.RunBtn.Enabled := false, this.PreviewBtn.Enabled := false
        uiWasVisible := DllCall("IsWindowVisible", "Ptr", this.UI.Hwnd)
        started := A_TickCount
        this.PairMetric.Text := "0", this.PathMetric.Text := "0 / 0", this.TimeMetric.Text := "—"
        try {
            this.Validate(this.S)
            if GetKeyState("LButton", "P")
                throw Error("Release your mouse button, then press F3 or F4 again.")
            this.X := ParseAxis(this.S.X), this.Y := ParseAxis(this.S.Y)
            this.UI.Hide()
            ToolTip()
            if !automatic
                Sleep(this.S.Delay)
            if this.Cancelled
                throw Error("Stopped before scanning.")
            if !this.Target || !WinExist("ahk_id " this.Target)
                this.Target := WindowAt(this.X[4], this.Y[4])
            if !this.Target || this.Target = this.UI.Hwnd
                throw Error("Game window not found. Activate the game and press F9.")
            if automatic {
                if !WinActive("ahk_id " this.Target)
                    throw Error("Auto complete paused because the game lost focus.")
            } else {
                WinActivate("ahk_id " this.Target)
                if !WinWaitActive("ahk_id " this.Target, , 2)
                    throw Error("Could not focus the game. Activate it and press F9.")
            }
            WinGetPos(&x, &y, &w, &h, "ahk_id " this.Target)
            this.Bounds := {x: x, y: y, w: w, h: h}
            if !this.BoardInWindow()
                throw Error("Grid centers are outside the bound game. Use Settings > Calibrate grid.")
            this.TimerPeriod := DllCall("winmm\timeBeginPeriod", "UInt", 1) = 0
            this.State("Reading the board", "Checking stable endpoint colors across multiple frames.", "SCANNING")
            this.Log("Scanning " this.S.Frames " board frames.")
            scanStarted := A_TickCount
            scan := this.ScanStable(automatic ? 2 : 0)
            if automatic && !this.Watcher.SameBoard(this.Watcher.Describe(scan), this.Watcher.Describe(suppliedScan))
                throw Error("Puzzle changed before auto complete. Waiting for the next scan.")
            this.Log("Scan: " (A_TickCount - scanStarted) " ms.")
            this.Grid := scan.grid, this.Pairs := scan.pairs
            this.PairMetric.Text := this.Pairs.Length
            this.PathMetric.Text := "0 / " this.Pairs.Length
            this.State("Finding paths", "Solver time limit: " this.S.Timeout " seconds.", "SOLVING")
            solver := FlowSolver(this.Grid, this.Pairs, this.S.Fill, this.S.Timeout * 1000, () => this.SolverCancelled())
            solveStarted := A_TickCount
            this.Paths := solver.Run()
            if !this.Paths.Length
                throw Error("No solution found. Check the scan graph, calibration, and color tolerance.")
            this.Log("Solve: " (A_TickCount - solveStarted) " ms / " solver.Nodes " steps / " this.Paths.Length " paths.")
            this.Check()
            if execute {
                this.State("Connecting paths", this.S.Lightning ? "Lightning Fast / one pass, then check the board." : "Confirming the starting drag before continuing.", "RUNNING")
                checked := this.ExecutePaths()
                this.State(checked ? "Path drawing checked" : "Lightning pass sent", checked ? "Planned cells or lines were detected. Confirm completion in the game." : "The final board could not be confirmed. It may have closed; check the game.", checked ? "CHECKED" : "SENT")
                this.Log(checked ? "All paths passed the connection checks. Confirm completion in the game." : "Lightning pass sent once; final drawing unconfirmed. No automatic retry.")
            } else {
                this.SelectPage(2)
                this.State("Preview ready", "Review the Scan Graph tab. Press F3 to scan again and connect.", "PREVIEW")
                this.Log("Preview complete. No mouse button was pressed.")
            }
        } catch as e {
            this.State(this.Cancelled ? "Stopped" : "Run stopped", e.Message, this.Cancelled ? "STOPPED" : "CHECK")
            this.Log(e.Message)
        } finally {
            this.Cleanup()
            this.DrawGraph()
            this.TimeMetric.Text := Format("{:.2f} s", (A_TickCount - started) / 1000)
            this.Busy := false
            this.RunBtn.Enabled := true, this.PreviewBtn.Enabled := true
            if this.Closing
                ExitApp()
            if !execute || (this.S.ReturnUI && (!automatic || uiWasVisible))
                this.UI.Show("NoActivate")
        }
    }
    SolverCancelled() {
        this.Check()
        return this.Cancelled
    }
    BoardInWindow() {
        b := this.Bounds
        return this.X[1] >= b.x && this.Y[1] >= b.y && this.X[7] < b.x + b.w && this.Y[7] < b.y + b.h
    }
    ReadPixel(x, y) {
        if IsObject(this.Frame)
            return this.Frame.Pixel(Round(x), Round(y))
        return Integer(PixelGetColor(Round(x), Round(y), this.S.Capture = "Normal" ? "" : this.S.Capture))
    }
    BeginFrame() {
        this.EndFrame()
        if this.S.Capture != "Normal" || this.CaptureFailed
            return
        d := Max(8, this.S.Radius)
        try this.Frame := ScreenFrame(this.X[1] - d, this.Y[1] - d, this.X[7] - this.X[1] + d * 2 + 1, this.Y[7] - this.Y[1] + d * 2 + 1, this.CaptureSource)
        catch as e {
            try {
                this.Frame := ScreenFrame(this.X[1] - d, this.Y[1] - d, this.X[7] - this.X[1] + d * 2 + 1, this.Y[7] - this.Y[1] + d * 2 + 1, this.Target)
                this.CaptureSource := this.Target
            } catch {
                this.CaptureFailed := true
                this.Log("Snapshot unavailable; using compatibility capture. " e.Message)
            }
        }
    }
    EndFrame() {
        if IsObject(this.Frame)
            this.Frame.Close()
        this.Frame := 0
    }
    Sample(x, y, radius := -1) {
        d := radius < 0 ? this.S.Radius : radius
        rs := [], gs := [], bs := []
        for offset in [[0, 0], [d, 0], [-d, 0], [0, d], [0, -d]] {
            rgb := Channels(this.ReadPixel(x + offset[1], y + offset[2]))
            rs.Push(rgb[1]), gs.Push(rgb[2]), bs.Push(rgb[3])
        }
        return (Median5(rs) << 16) | (Median5(gs) << 8) | Median5(bs)
    }
    IsEmpty(color) => Max(Channels(color)*) <= this.S.Dark || ColorDistance(color, Integer("0x" this.S.Empty)) <= 18
    ScanFrame() {
        cells := []
        this.Check()
        this.BeginFrame()
        try {
            Loop 49 {
                cell := A_Index
                pos := CellRC(cell)
                cells.Push(this.Sample(this.X[pos.c], this.Y[pos.r]))
                if Mod(cell, 7) = 0
                    Sleep(-1)
            }
        } finally {
            this.EndFrame()
        }
        this.Check()
        return cells
    }
    ScanStable(frames := 0) {
        if !frames
            frames := this.S.Frames
        first := this.ScanFrame()
        Loop frames - 1 {
            this.Wait(35)
            next := this.ScanFrame()
            Loop 49 {
                a := first[A_Index], b := next[A_Index]
                if this.IsEmpty(a) != this.IsEmpty(b) || (!this.IsEmpty(a) && ColorDistance(a, b) > this.S.ScanTol)
                    throw Error("Board changed during scanning. Wait for the puzzle to settle, then retry.")
            }
            first := next
        }
        foundColor := false
        for color in first
            if !this.IsEmpty(color) {
                foundColor := true
                break
            }
        if !foundColor && this.S.Capture = "Normal" && !this.CaptureFailed {
            this.CaptureFailed := true
            if !this.AutoReading
                this.Log("Snapshot was blank; checking with compatibility capture.")
            return this.ScanStable(frames)
        }
        pairs := [], grid := []
        for cell, color in first {
            if this.IsEmpty(color) {
                grid.Push(0)
                continue
            }
            matches := []
            for pair in pairs
                if ColorDistance(color, pair.color) <= this.S.ScanTol
                    matches.Push(pair.id)
            if matches.Length > 1
                throw Error("Endpoint colors are ambiguous. Lower endpoint color tolerance.")
            if !matches.Length {
                id := pairs.Length + 1
                pairs.Push({id: id, a: cell, b: 0, color: color, count: 1})
            } else {
                id := matches[1], pair := pairs[id]
                pair.count += 1
                if pair.count > 2
                    throw Error("More than two endpoints share a color. Start a fresh board or lower scan tolerance.")
                pair.b := cell
            }
            grid.Push(id)
        }
        if !pairs.Length
            throw Error("No endpoints found. Check grid calibration and empty brightness.")
        for pair in pairs
            if pair.count != 2
                throw Error("Unmatched endpoint #" Format("{:06X}", pair.color) ". Check calibration or raise scan tolerance slightly.")
        return {grid: grid, pairs: pairs}
    }

    MoveSegment(a, b, duration) {
        pa := CellRC(a), pb := CellRC(b)
        x1 := this.X[pa.c], y1 := this.Y[pa.r], x2 := this.X[pb.c], y2 := this.Y[pb.r]
        steps := Max(4, Ceil(Max(Abs(x2 - x1), Abs(y2 - y1)) / 9))
        began := MonotonicMs()
        Loop steps {
            this.Check()
            t := A_Index / steps
            this.MoveMouse(Round(x1 + (x2 - x1) * t), Round(y1 + (y2 - y1) * t))
            remaining := duration * t - (MonotonicMs() - began)
            if remaining > 0
                this.Wait(remaining)
            else
                Sleep(-1)
        }
    }
    EdgeMatches(a, b, expected) {
        pa := CellRC(a), pb := CellRC(b)
        x1 := this.X[pa.c], y1 := this.Y[pa.r], x2 := this.X[pb.c], y2 := this.Y[pb.r]
        ; Sample away from both endpoint dots and from the cursor at the cell center.
        for fraction in [0.35, 0.65] {
            x := Round(x1 + (x2 - x1) * fraction), y := Round(y1 + (y2 - y1) * fraction)
            hits := 0
            for offset in [-2, 0, 2] {
                color := this.ReadPixel(x + (y1 != y2 ? offset : 0), y + (x1 != x2 ? offset : 0))
                if !this.IsEmpty(color) && HueMatches(color, expected, this.S.WireTol)
                    hits++
            }
            if hits < 2
                return false
        }
        return true
    }
    FilledCellMatches(cell, expected) {
        ; Endpoint colors existed before the drag and cannot prove acquisition.
        if this.Grid.Length != 49 || this.Grid[cell] != 0
            return false
        pos := CellRC(cell), x := this.X[pos.c], y := this.Y[pos.r]
        hits := 0
        for offset in [[-7,-7], [7,-7], [-7,7], [7,7]] {
            color := this.ReadPixel(x + offset[1], y + offset[2])
            if !this.IsEmpty(color) && HueMatches(color, expected, this.S.WireTol)
                hits++
        }
        return hits >= 3
    }
    ConnectionMatches(a, b, expected) {
        return this.FilledCellMatches(b, expected) || this.FilledCellMatches(a, expected) || this.EdgeMatches(a, b, expected)
    }
    PathMatches(path) {
        interiors := 0
        for index, cell in path.cells {
            if this.Grid.Length != 49 || this.Grid[cell] != 0
                continue
            interiors++
            if this.FilledCellMatches(cell, path.color)
                continue
            if index = 1 || index = path.cells.Length
                return false
            if !this.EdgeMatches(path.cells[index - 1], cell, path.color)
                || !this.EdgeMatches(cell, path.cells[index + 1], path.color)
                return false
        }
        ; With no empty interior cell, an actual intercell line is the only visual evidence.
        if !interiors {
            Loop path.cells.Length - 1
                if !this.EdgeMatches(path.cells[A_Index], path.cells[A_Index + 1], path.color)
                    return false
        }
        return true
    }
    WaitForEdge(a, b, color, timeout) {
        deadline := MonotonicMs() + timeout
        consecutive := 0
        while MonotonicMs() < deadline {
            this.Wait(12)
            this.BeginFrame()
            try matches := this.ConnectionMatches(a, b, color)
            finally this.EndFrame()
            if matches {
                consecutive++
                if consecutive >= 2
                    return true
            } else
                consecutive := 0
        }
        return false
    }
    ExecutePaths() {
        if this.S.Lightning
            return this.ExecuteLightning()
        done := 0
        for path in this.Paths {
            connected := false
            Loop this.S.Retries {
                attempt := A_Index
                this.Check()
                this.ReleaseMouse()
                this.EnsureBoardPresent()
                first := CellRC(path.cells[1])
                this.StartPoint := {x: this.X[first.c], y: this.Y[first.r]}
                this.ActiveInput := Mod(attempt, 2) = 1 ? this.S.Input : (this.S.Input = "Input" ? "Event" : "Input")
                this.TweenMouse(this.StartPoint.x, this.StartPoint.y)
                this.Wait(this.S.Settle + (attempt - 1) * 12)
                failed := false
                try {
                    this.PressMouse()
                    this.Wait(this.S.Press + (attempt - 1) * 20)
                    Loop path.cells.Length - 1 {
                        moveIndex := A_Index
                        a := path.cells[A_Index], b := path.cells[A_Index + 1]
                        this.MoveSegment(a, b, this.S.Segment + (attempt - 1) * 16)
                        if moveIndex = 1 {
                            ; Verify that the first drag actually started before moving farther.
                            if !this.WaitForEdge(a, b, path.color, this.S.Verify + (attempt - 1) * 35) {
                                failed := true
                                break
                            }
                        } else {
                            this.Wait(16)
                        }
                    }
                    this.Wait(this.S.Release + (attempt - 1) * 12)
                    if !failed {
                        last := CellRC(path.cells[-1])
                        this.EnsureCursor(this.X[last.c], this.Y[last.r])
                    }
                } finally
                    this.ReleaseMouse()
                this.Wait(55)
                ; Interior/edge samples avoid the cursor at the completed endpoint.
                if !failed {
                    this.BeginFrame()
                    try {
                        failed := !this.PathMatches(path)
                    } finally this.EndFrame()
                    this.Check()
                }
                if !failed {
                    connected := true
                    done++
                    this.PathMetric.Text := done " / " this.Paths.Length
                    this.Log("Pair " path.id " drawing checked" (attempt > 1 ? " on attempt " attempt : "") ".")
                    break
                }
                this.EnsureBoardPresent()
                this.Log("Pair " path.id ": drag not confirmed (" this.ActiveInput "); retrying at a steadier pace (" attempt "/" this.S.Retries ").")
                this.Wait(100)
            }
            if !connected
                throw Error("Pair " path.id " failed after " this.S.Retries " attempts. Try Careful speed or check the scan graph.")
        }
        return true
    }

    ExecuteLightning() {
        this.Check()
        this.ReleaseMouse()
        this.EnsureBoardPresent()
        edges := 0
        for path in this.Paths
            edges += path.cells.Length - 1
        ; Keep the nominal input budget near two seconds even with many pairs.
        transferLimit := Max(20, Min(60, Floor((1800 - edges * this.S.Segment
            - this.Paths.Length * (this.S.Press + this.S.Settle + this.S.Release)) / this.Paths.Length)))
        sent := 0
        for path in this.Paths {
            this.Check()
            if sent
                this.EnsureBoardPresent()
            first := CellRC(path.cells[1])
            this.StartPoint := {x: this.X[first.c], y: this.Y[first.r]}
            this.ActiveInput := this.S.Input
            this.TweenMouse(this.StartPoint.x, this.StartPoint.y, transferLimit)
            this.Wait(this.S.Settle)
            try {
                this.PressMouse()
                this.Wait(this.S.Press)
                Loop path.cells.Length - 1
                    this.MoveSegment(path.cells[A_Index], path.cells[A_Index + 1], this.S.Segment)
                this.Wait(this.S.Release)
                last := CellRC(path.cells[-1])
                this.EnsureCursor(this.X[last.c], this.Y[last.r])
            } finally this.ReleaseMouse()
            sent++
            this.PathMetric.Text := "sent " sent " / " this.Paths.Length
        }
        this.Wait(45)
        this.BeginFrame()
        checked := 0
        try {
            for path in this.Paths
                if this.PathMatches(path)
                    checked++
        } finally this.EndFrame()
        this.Check()
        this.PathMetric.Text := checked " / " this.Paths.Length
        this.Log("Lightning drawing: " checked " of " this.Paths.Length " paths visually confirmed.")
        return checked = this.Paths.Length
    }

    EnsureBoardPresent() {
        this.Check()
        pointer := this.CursorPosition(), inspected := 0
        this.BeginFrame()
        try {
            for pair in this.Pairs {
                for cell in [pair.a, pair.b] {
                    pos := CellRC(cell)
                    ; A game cursor can hide its current dot. Check the remaining
                    ; dots without moving away from the finished path.
                    if Abs(pointer.x - this.X[pos.c]) <= 18 && Abs(pointer.y - this.Y[pos.r]) <= 18
                        continue
                    inspected++
                    color := this.Sample(this.X[pos.c], this.Y[pos.r])
                    if this.IsEmpty(color) || !HueMatches(color, pair.color, this.S.WireTol)
                        throw Error("Puzzle changed or disappeared. It may have completed; check the game before running again.")
                }
            }
            if !inspected
                throw Error("Cannot confirm uncovered endpoints. Move the cursor clear of the dots.")
        } finally this.EndFrame()
    }

    DrawGraph() {
        bitmap := BoardBitmap(this.Grid, this.Pairs, this.Paths)
        this.Graph.Value := "HBITMAP:*" bitmap
        if this.Bitmap
            DllCall("gdi32\DeleteObject", "Ptr", this.Bitmap)
        this.Bitmap := bitmap
        if !this.Pairs.Length {
            this.Legend.Value := "No valid scan yet.`r`n`r`nUse F4 on a fresh puzzle.`r`nCheck calibration if scanning fails."
            this.GraphInfo.Text := "7 × 7 grid / 49 cells"
            return
        }
        lines := []
        for pair in this.Pairs {
            a := CellRC(pair.a), b := CellRC(pair.b)
            description := "PAIR " pair.id "   #" Format("{:06X}", pair.color)
            for path in this.Paths
                if path.id = pair.id
                    description .= "  /  " path.cells.Length " cells"
            lines.Push(description)
            lines.Push("r" a.r " c" a.c "  →  r" b.r " c" b.c)
        }
        this.Legend.Value := Join(lines, "`r`n")
        covered := 0
        for path in this.Paths
            covered += path.cells.Length
        this.GraphInfo.Text := covered " / 49 cells in planned paths"
    }
}

MonotonicMs() {
    static frequency := 0
    if !frequency
        DllCall("QueryPerformanceFrequency", "Int64*", &frequency)
    counter := 0
    DllCall("QueryPerformanceCounter", "Int64*", &counter)
    return counter * 1000 / frequency
}
ParseAxis(text) {
    parts := StrSplit(text, ",")
    if parts.Length != 7
        throw Error("Each coordinate list needs exactly seven comma-separated centers.")
    values := []
    for part in parts {
        value := Trim(part)
        if !RegExMatch(value, "^-?\d+$")
            throw Error("Coordinates must be whole numbers.")
        value := Integer(value)
        if values.Length && value - values[-1] < 15
            throw Error("Centers must increase by at least 15 pixels.")
        values.Push(value)
    }
    ; Bounds are checked against the target window at run time, including multiple monitors.
    if Abs(values[1]) > 100000 || Abs(values[7]) > 100000
        throw Error("Coordinate range is invalid.")
    return values
}
CellRC(cell) => {r: (cell - 1) // 7 + 1, c: Mod(cell - 1, 7) + 1}
Channels(color) => [(color >> 16) & 255, (color >> 8) & 255, color & 255]
RGBToBGR(color) => ((color & 255) << 16) | (color & 0xFF00) | ((color >> 16) & 255)
ColorDistance(a, b) {
    ca := Channels(a), cb := Channels(b)
    return Max(Abs(ca[1] - cb[1]), Abs(ca[2] - cb[2]), Abs(ca[3] - cb[3]))
}
HueMatches(actual, expected, tolerance) {
    a := Channels(actual), b := Channels(expected)
    ma := Max(a*), mb := Max(b*)
    if ma < 1 || mb < 1
        return false
    return Max(Abs(a[1] * 255 / ma - b[1] * 255 / mb),
        Abs(a[2] * 255 / ma - b[2] * 255 / mb), Abs(a[3] * 255 / ma - b[3] * 255 / mb)) <= tolerance
}
Median5(values) {
    Loop values.Length - 1 {
        i := A_Index + 1
        while i > 1 && values[i] < values[i - 1] {
            tmp := values[i], values[i] := values[i - 1], values[i - 1] := tmp
            i--
        }
    }
    return values[3]
}
Join(items, separator := ",") {
    result := ""
    for index, value in items
        result .= (index > 1 ? separator : "") value
    return result
}
WindowAt(x, y) {
    point := (x & 0xFFFFFFFF) | ((y & 0xFFFFFFFF) << 32)
    hwnd := DllCall("WindowFromPoint", "Int64", point, "Ptr")
    return hwnd ? DllCall("GetAncestor", "Ptr", hwnd, "UInt", 2, "Ptr") : 0
}

BoardBitmap(grid, pairs, paths, size := 434) {
    screen := DllCall("GetDC", "Ptr", 0, "Ptr")
    dc := DllCall("gdi32\CreateCompatibleDC", "Ptr", screen, "Ptr")
    bmp := DllCall("gdi32\CreateCompatibleBitmap", "Ptr", screen, "Int", size, "Int", size, "Ptr")
    DllCall("ReleaseDC", "Ptr", 0, "Ptr", screen)
    old := DllCall("gdi32\SelectObject", "Ptr", dc, "Ptr", bmp, "Ptr")
    try {
        GdiFill(dc, 0, 0, size, size, 0x19212E)
        margin := 31, step := 62
        Loop 7 {
            y := margin + (A_Index - 1) * step
            Loop 7 {
                x := margin + (A_Index - 1) * step
                GdiFill(dc, x - 27, y - 27, 54, 54, 0x202B3B)
                GdiCircle(dc, x, y, 3, 0x41516B)
            }
        }
        for path in paths {
            Loop path.cells.Length - 1 {
                a := CellRC(path.cells[A_Index]), b := CellRC(path.cells[A_Index + 1])
                GdiLine(dc, margin + (a.c - 1) * step, margin + (a.r - 1) * step,
                    margin + (b.c - 1) * step, margin + (b.r - 1) * step, path.color, 10)
            }
            for cell in path.cells {
                p := CellRC(cell)
                GdiCircle(dc, margin + (p.c - 1) * step, margin + (p.r - 1) * step, 5, path.color)
            }
        }
        font := DllCall("gdi32\CreateFontW", "Int", -17, "Int", 0, "Int", 0, "Int", 0, "Int", 700,
            "UInt", 0, "UInt", 0, "UInt", 0, "UInt", 1, "UInt", 0, "UInt", 0, "UInt", 5, "UInt", 0, "Str", "Segoe UI", "Ptr")
        oldFont := DllCall("gdi32\SelectObject", "Ptr", dc, "Ptr", font, "Ptr")
        for pair in pairs {
            for cell in [pair.a, pair.b] {
                if !cell
                    continue
                pos := CellRC(cell), x := margin + (pos.c - 1) * step, y := margin + (pos.r - 1) * step
                GdiCircle(dc, x, y, 18, 0xEAF0FC)
                GdiCircle(dc, x, y, 15, pair.color)
                rect := Buffer(16)
                NumPut("Int", x - 17, "Int", y - 17, "Int", x + 17, "Int", y + 17, rect)
                DllCall("gdi32\SetBkMode", "Ptr", dc, "Int", 1)
                ch := Channels(pair.color)
                fg := (ch[1] * 0.299 + ch[2] * 0.587 + ch[3] * 0.114) > 150 ? 0x132030 : 0xFFFFFF
                DllCall("gdi32\SetTextColor", "Ptr", dc, "UInt", RGBToBGR(fg))
                DllCall("DrawTextW", "Ptr", dc, "Str", String(pair.id), "Int", -1, "Ptr", rect, "UInt", 0x25)
            }
        }
        DllCall("gdi32\SelectObject", "Ptr", dc, "Ptr", oldFont)
        DllCall("gdi32\DeleteObject", "Ptr", font)
    } finally {
        DllCall("gdi32\SelectObject", "Ptr", dc, "Ptr", old)
        DllCall("gdi32\DeleteDC", "Ptr", dc)
    }
    return bmp
}
GdiFill(dc, x, y, w, h, color) {
    rect := Buffer(16)
    NumPut("Int", x, "Int", y, "Int", x + w, "Int", y + h, rect)
    brush := DllCall("gdi32\CreateSolidBrush", "UInt", RGBToBGR(color), "Ptr")
    DllCall("FillRect", "Ptr", dc, "Ptr", rect, "Ptr", brush)
    DllCall("gdi32\DeleteObject", "Ptr", brush)
}
GdiCircle(dc, x, y, radius, color) {
    brush := DllCall("gdi32\CreateSolidBrush", "UInt", RGBToBGR(color), "Ptr")
    old := DllCall("gdi32\SelectObject", "Ptr", dc, "Ptr", brush, "Ptr")
    pen := DllCall("gdi32\GetStockObject", "Int", 8, "Ptr")
    oldPen := DllCall("gdi32\SelectObject", "Ptr", dc, "Ptr", pen, "Ptr")
    DllCall("gdi32\Ellipse", "Ptr", dc, "Int", x - radius, "Int", y - radius, "Int", x + radius + 1, "Int", y + radius + 1)
    DllCall("gdi32\SelectObject", "Ptr", dc, "Ptr", oldPen)
    DllCall("gdi32\SelectObject", "Ptr", dc, "Ptr", old)
    DllCall("gdi32\DeleteObject", "Ptr", brush)
}
GdiLine(dc, x1, y1, x2, y2, color, width) {
    pen := DllCall("gdi32\CreatePen", "Int", 0, "Int", width, "UInt", RGBToBGR(color), "Ptr")
    old := DllCall("gdi32\SelectObject", "Ptr", dc, "Ptr", pen, "Ptr")
    DllCall("gdi32\MoveToEx", "Ptr", dc, "Int", x1, "Int", y1, "Ptr", 0)
    DllCall("gdi32\LineTo", "Ptr", dc, "Int", x2, "Int", y2)
    DllCall("gdi32\SelectObject", "Ptr", dc, "Ptr", old)
    DllCall("gdi32\DeleteObject", "Ptr", pen)
}



class FlowSolver {
    __New(grid, pairs, fillAll := false, timeoutMs := 10000, cancelCheck := 0) {
        if !(grid is Array) || grid.Length != 49
            throw Error("The solver needs a 7 by 7 board.")
        if !(pairs is Array) || pairs.Length < 1 || pairs.Length > 24
            throw Error("The board needs at least one endpoint pair.")
        this.Initial := grid.Clone()
        this.Pairs := []
        this.FillAll := !!fillAll
        this.TimeoutMs := Max(250, timeoutMs)
        this.CancelCheck := cancelCheck
        this.MaxNodes := 500000
        this.Nodes := 0
        this.Neighbors := []
        this.Sign := []
        ids := Map()
        endpoints := Map()
        for p in pairs {
            if !IsInteger(p.id) || p.id < 1 || ids.Has(p.id)
                throw Error("Endpoint pair IDs must be unique positive integers.")
            if !IsInteger(p.a) || !IsInteger(p.b) || p.a < 1 || p.a > 49 || p.b < 1 || p.b > 49 || p.a = p.b
                throw Error("A pair has invalid endpoint positions.")
            if endpoints.Has(p.a) || endpoints.Has(p.b)
                throw Error("Two pairs share an endpoint cell.")
            ids[p.id] := true
            endpoints[p.a] := p.id
            endpoints[p.b] := p.id
            this.Pairs.Push({id: p.id, a: p.a, b: p.b, color: p.color})
        }
        Loop 49 {
            cell := A_Index
            if !IsInteger(grid[cell]) || (endpoints.Has(cell) ? grid[cell] != endpoints[cell] : grid[cell] != 0)
                throw Error("The board must contain empty cells and exactly two endpoints per color.")
            r := (cell - 1) // 7
            c := Mod(cell - 1, 7)
            adjacent := []
            if r > 0
                adjacent.Push(cell - 7)
            if c > 0
                adjacent.Push(cell - 1)
            if c < 6
                adjacent.Push(cell + 1)
            if r < 6
                adjacent.Push(cell + 7)
            this.Neighbors.Push(adjacent)
            this.Sign.Push(Mod(r + c, 2) ? -1 : 1)
        }
    }

    Run() {
        this.Board := this.Initial.Clone()
        this.Done := []
        this.Paths := []
        this.DoneCount := 0
        this.EmptyCount := 0
        this.Nodes := 0
        for value in this.Board
            if value = 0
                this.EmptyCount++
        for p in this.Pairs {
            this.Done.Push(false)
            this.Paths.Push(0)
        }
        this.Started := A_TickCount
        this.Checkpoint()
        return this.SearchPairs() ? this.Paths : []
    }

    Checkpoint() {
        Sleep(-1)
        if IsObject(this.CancelCheck) && this.CancelCheck.Call()
            throw Error("Solve stopped.")
        if A_TickCount - this.Started >= this.TimeoutMs
            throw Error("Search time limit reached. Increase the solve limit in Settings.")
        if this.Nodes > this.MaxNodes
            throw Error("Search node limit reached. This board needs more search.")
    }

    SearchPairs() {
        if this.DoneCount = this.Pairs.Length
            return !this.FillAll || this.EmptyCount = 0
        if this.FillAll && !this.FullFillPrune(0, 0)
            return false
        chosen := 0
        bestExits := 5
        bestArea := 50
        bestDistance := -1
        for i, p in this.Pairs {
            if this.Done[i]
                continue
            distances := this.DistanceMap(p.b, p.a)
            if distances[p.a] < 0
                return false
            exits := Min(this.ExitCount(p.a, p.b), this.ExitCount(p.b, p.a))
            area := 0
            for distance in distances
                if distance >= 0
                    area++
            if exits < bestExits || (exits = bestExits && (area < bestArea || (area = bestArea && distances[p.a] > bestDistance))) {
                chosen := i
                bestExits := exits
                bestArea := area
                bestDistance := distances[p.a]
            }
        }
        return this.SearchPath(chosen, this.Pairs[chosen].a, [this.Pairs[chosen].a])
    }

    SearchPath(pairIndex, head, path) {
        this.Nodes++
        if Mod(this.Nodes, 128) = 0 || this.Nodes > this.MaxNodes
            this.Checkpoint()
        p := this.Pairs[pairIndex]
        if head = p.b {
            this.Done[pairIndex] := true
            this.DoneCount++
            this.Paths[pairIndex] := {id: p.id, color: p.color, cells: path.Clone()}
            if this.SearchPairs()
                return true
            this.Paths[pairIndex] := 0
            this.DoneCount--
            this.Done[pairIndex] := false
            return false
        }

        distances := this.DistanceMap(p.b, head)
        if distances[head] < 0
            return false
        ; A partial path must not strand any other reserved pair.
        for i, other in this.Pairs {
            if i = pairIndex || this.Done[i]
                continue
            if this.DistanceMap(other.b, other.a)[other.a] < 0
                return false
        }
        if this.FillAll && !this.FullFillPrune(pairIndex, head)
            return false

        candidates := []
        for next in this.Neighbors[head] {
            if (this.Board[next] = 0 || next = p.b) && distances[next] >= 0 {
                ; At most four candidates; insertion sorting avoids extra libraries.
                position := candidates.Length + 1
                for j, existing in candidates {
                    if distances[next] < distances[existing] {
                        position := j
                        break
                    }
                }
                candidates.InsertAt(position, next)
            }
        }
        for next in candidates {
            oldValue := this.Board[next]
            this.Board[next] := p.id
            if oldValue = 0
                this.EmptyCount--
            path.Push(next)
            if this.SearchPath(pairIndex, next, path)
                return true
            path.Pop()
            this.Board[next] := oldValue
            if oldValue = 0
                this.EmptyCount++
        }
        return false
    }

    DistanceMap(target, allowedHead) {
        distances := []
        Loop 49
            distances.Push(-1)
        distances[target] := 0
        queue := [target]
        cursor := 1
        while cursor <= queue.Length {
            current := queue[cursor++]
            for next in this.Neighbors[current] {
                if distances[next] < 0 && (this.Board[next] = 0 || next = allowedHead) {
                    distances[next] := distances[current] + 1
                    queue.Push(next)
                }
            }
        }
        return distances
    }

    ExitCount(endpoint, other) {
        count := 0
        for next in this.Neighbors[endpoint]
            if this.Board[next] = 0 || next = other
                count++
        return count
    }

    FullFillPrune(activePair, head) {
        terminals := []
        visited := []
        Loop 49 {
            terminals.Push(false)
            visited.Push(false)
        }
        expectedBalance := 0
        for i, p in this.Pairs {
            if this.Done[i]
                continue
            start := i = activePair ? head : p.a
            terminals[start] := true
            terminals[p.b] := true
            if this.Sign[start] = this.Sign[p.b]
                expectedBalance -= this.Sign[start]
        }
        balance := 0
        Loop 49 {
            cell := A_Index
            if this.Board[cell] != 0
                continue
            balance += this.Sign[cell]
            exits := 0
            for next in this.Neighbors[cell]
                if this.Board[next] = 0 || terminals[next]
                    exits++
            ; Every unoccupied cell must eventually be internal to a path.
            if exits < 2
                return false
        }
        if balance != expectedBalance
            return false

        ; An empty component needs both ends of at least one remaining path.
        Loop 49 {
            seed := A_Index
            if this.Board[seed] != 0 || visited[seed]
                continue
            touches := Map()
            queue := [seed]
            visited[seed] := true
            cursor := 1
            while cursor <= queue.Length {
                cell := queue[cursor++]
                for next in this.Neighbors[cell] {
                    if terminals[next]
                        touches[next] := true
                    if this.Board[next] = 0 && !visited[next] {
                        visited[next] := true
                        queue.Push(next)
                    }
                }
            }
            canFill := false
            for i, p in this.Pairs {
                if this.Done[i]
                    continue
                start := i = activePair ? head : p.a
                if touches.Has(start) && touches.Has(p.b) {
                    canFill := true
                    break
                }
            }
            if !canFill
                return false
        }
        return true
    }
}


; One synchronous screen-region capture; all samples read directly from its memory.
; 32-bit BI_RGB pixels are stored as B, G, R, unused (numeric 0x00RRGGBB).
class ScreenFrame {
    __New(x, y, w, h, sourceHwnd := 0) {
        this.X := x, this.Y := y, this.Width := w, this.Height := h
        this.SourceHwnd := sourceHwnd
        this.Bits := 0, this.Bitmap := 0, this.MemoryDC := 0
        this.ScreenDC := 0, this.PreviousBitmap := 0
        if !IsInteger(x) || !IsInteger(y) || !IsInteger(w) || !IsInteger(h)
            throw ValueError("Capture coordinates and dimensions must be integers.")
        if w < 1 || h < 1 || w > 0x7FFFFFFF || h > 0x7FFFFFFF || w * h > 0x1FFFFFFF
            throw ValueError("Capture dimensions must be positive and fit in a bitmap.")
        this.Stride := w * 4
        try {
            sourceX := x, sourceY := y
            if sourceHwnd {
                ; Optional bound-window fallback keeps the public pixel coordinates absolute.
                point := Buffer(8)
                NumPut("Int", x, "Int", y, point)
                if !DllCall("user32\ScreenToClient", "Ptr", sourceHwnd, "Ptr", point, "Int")
                    throw Error("Screen capture failed: the bound window is unavailable.")
                sourceX := NumGet(point, 0, "Int"), sourceY := NumGet(point, 4, "Int")
            }
            this.ScreenDC := DllCall("user32\GetDC", "Ptr", sourceHwnd, "Ptr")
            if !this.ScreenDC
                throw Error("Screen capture failed: GetDC returned no device context.")
            this.MemoryDC := DllCall("gdi32\CreateCompatibleDC", "Ptr", this.ScreenDC, "Ptr")
            if !this.MemoryDC
                throw Error("Screen capture failed: CreateCompatibleDC returned no device context.")

            info := Buffer(40, 0)
            NumPut("UInt", 40, "Int", w, "Int", -h, "UShort", 1, "UShort", 32, info)
            ; Negative biHeight makes the first memory row the screen's top row.
            bits := 0
            this.Bitmap := DllCall("gdi32\CreateDIBSection", "Ptr", this.ScreenDC,
                "Ptr", info, "UInt", 0, "Ptr*", &bits, "Ptr", 0, "UInt", 0, "Ptr")
            if !this.Bitmap || !bits
                throw Error("Screen capture failed: CreateDIBSection (Windows error " A_LastError ").")
            this.Bits := bits
            previous := DllCall("gdi32\SelectObject", "Ptr", this.MemoryDC, "Ptr", this.Bitmap, "Ptr")
            if !previous || previous = -1 || previous = 0xFFFFFFFF
                throw Error("Screen capture failed: SelectObject could not select the bitmap.")
            this.PreviousBitmap := previous
            if !DllCall("gdi32\BitBlt", "Ptr", this.MemoryDC, "Int", 0, "Int", 0,
                "Int", w, "Int", h, "Ptr", this.ScreenDC, "Int", sourceX, "Int", sourceY,
                "UInt", 0x00CC0020, "Int")
                throw Error("Screen capture failed: BitBlt (Windows error " A_LastError ").")
            ; Finish GDI writes before accessing the DIB's pointer with NumGet.
            if !DllCall("gdi32\GdiFlush", "Int")
                throw Error("Screen capture failed: GdiFlush could not finish the bitmap.")
        } catch as captureError {
            this.Close()
            throw captureError
        }
    }

    Pixel(x, y) {
        if !this.Bits
            throw Error("The captured frame is closed.")
        if !IsInteger(x) || !IsInteger(y) || x < this.X || y < this.Y
            || x >= this.X + this.Width || y >= this.Y + this.Height
            throw ValueError("Pixel coordinates are outside the captured region.")
        return NumGet(this.Bits, (y - this.Y) * this.Stride + (x - this.X) * 4, "UInt") & 0xFFFFFF
    }

    Close() {
        ; Clear handles first so explicit cleanup and __Delete cannot release twice.
        bitmap := this.Bitmap, memoryDC := this.MemoryDC, screenDC := this.ScreenDC
        previous := this.PreviousBitmap
        this.Bits := 0, this.Bitmap := 0, this.MemoryDC := 0
        this.ScreenDC := 0, this.PreviousBitmap := 0
        if memoryDC {
            if previous
                DllCall("gdi32\SelectObject", "Ptr", memoryDC, "Ptr", previous, "Ptr")
            ; Delete the DC before the bitmap, even if restoring the selection failed.
            DllCall("gdi32\DeleteDC", "Ptr", memoryDC, "Int")
        }
        if bitmap
            DllCall("gdi32\DeleteObject", "Ptr", bitmap, "Int")
        if screenDC
            DllCall("user32\ReleaseDC", "Ptr", this.SourceHwnd, "Ptr", screenDC, "Int")
    }

    __Delete() {
        try this.Close()
    }
}



; Polling never focuses a window or moves the mouse. ReadAutoBoard supplies a
; board already confirmed by two captured frames; Run rechecks it before input.
class PuzzleWatcher {
    __New(app) {
        this.App := app
        this.TimerCallback := ObjBindMethod(this, "Tick")
        this.Running := false
        this.Checking := false
        this.LastPresented := 0
        this.LastAttempt := 0
        this.MissingCount := 0
        this.LastStatus := ""
    }

    Start() {
        if !this.App.S.AutoScan && !this.App.S.AutoComplete {
            this.Stop()
            return
        }
        if this.Running
            return
        this.Running := true
        this.LastPresented := 0
        this.LastAttempt := 0
        this.MissingCount := 0
        this.SetPolling(1000)
        this.Status(this.App.S.AutoComplete ? "Watching for a puzzle every second." : "Auto scan is watching every second.")
    }

    Stop() {
        this.Running := false
        this.SetPolling(0)
        this.Status("Automatic scanning and completion are stopped.")
    }

    SetPolling(period) => SetTimer(this.TimerCallback, period)

    Tick(*) {
        host := this.App
        if !this.Running || this.Checking || host.Busy || host.Calibrating
            return
        if !host.S.AutoScan && !host.S.AutoComplete {
            this.Stop()
            return
        }
        this.Checking := true
        try {
            ; Unrelated foreground apps and an obscured board are a pause, not
            ; evidence that the puzzle disappeared or a reason to rearm it.
            if HasMethod(host, "CanAutoPoll") && !host.CanAutoPoll()
                return
            try {
                scan := host.ReadAutoBoard()
                board := this.Describe(scan)
            } catch {
                board := 0
            }
            ; Stop may interrupt a frame capture. Do not publish or run its result.
            if !this.Running || host.Busy || host.Calibrating
                return
            if !IsObject(board) {
                this.MissingCount += 1
                ; One lost frame can be an animation. Two polls rearm detection
                ; for a later occurrence of the same endpoint arrangement.
                if this.MissingCount >= 2 {
                    this.LastAttempt := 0
                    this.LastPresented := 0
                }
                this.Status("Watching for a puzzle every second.")
                return
            }
            this.MissingCount := 0
            if host.S.AutoScan && !this.SameBoard(board, this.LastPresented) {
                host.ShowAutoBoard(scan)
                this.LastPresented := board
            }
            if !this.Running || host.Busy || host.Calibrating
                return
            canComplete := !HasMethod(host, "CanAutoComplete") || host.CanAutoComplete(scan)
            if host.S.AutoComplete && canComplete && !this.SameBoard(board, this.LastAttempt) {
                ; Consume before calling Run. A failure remains consumed until
                ; the board changes or disappears for two complete polls.
                this.LastAttempt := board
                this.Status("Puzzle detected. Completing it now.")
                host.Run(true, scan, true)
            } else if host.S.AutoComplete && !canComplete {
                this.Status("Puzzle detected. Focus the game to complete it.")
            } else {
                this.Status(host.S.AutoComplete ? "Waiting for a new puzzle." : "Scan graph is up to date.")
            }
        } catch {
            ; A failed UI update or run must not leave polling locked. Run owns
            ; its user-facing error details; this status avoids a retry loop.
            if this.Running
                this.Status("Waiting for a new puzzle.")
        } finally {
            this.Checking := false
        }
    }

    Status(message) {
        if message = this.LastStatus
            return
        this.LastStatus := message
        this.App.AutoStatus(message)
    }

    Describe(scan) {
        if !IsObject(scan) || !scan.HasOwnProp("grid") || !scan.HasOwnProp("pairs")
            return 0
        if !(scan.grid is Array) || scan.grid.Length != 49 || !(scan.pairs is Array)
            return 0
        if !scan.pairs.Length || scan.pairs.Length > 24
            return 0
        ordered := [], occupied := Map(), ids := Map()
        for pair in scan.pairs {
            if !IsInteger(pair.id) || pair.id < 1 || !IsInteger(pair.a) || !IsInteger(pair.b)
                return 0
            if pair.a < 1 || pair.a > 49 || pair.b < 1 || pair.b > 49 || pair.a = pair.b
                return 0
            if !IsInteger(pair.color) || pair.color < 0 || pair.color > 0xFFFFFF
                return 0
            if ids.Has(pair.id) || occupied.Has(pair.a) || occupied.Has(pair.b)
                return 0
            ids[pair.id] := true
            occupied[pair.a] := pair.id, occupied[pair.b] := pair.id
            ordered.Push({id: pair.id, a: Min(pair.a, pair.b), b: Max(pair.a, pair.b), color: pair.color})
        }
        ; Canonical ordering makes matching independent of scan-assigned IDs.
        Loop ordered.Length - 1 {
            i := A_Index + 1, j := i
            while j > 1 && ordered[j].a < ordered[j - 1].a {
                swap := ordered[j - 1]
                ordered[j - 1] := ordered[j], ordered[j] := swap
                j -= 1
            }
        }
        canonical := Map(), colors := [], topology := "", key := ""
        for index, pair in ordered {
            canonical[pair.id] := index
            colors.Push(pair.color)
            topology .= pair.a ":" pair.b ";"
            key .= pair.a ":" pair.b ":" this.QuantizedColor(pair.color) ";"
        }
        topology .= "|", key .= "|"
        for cell, id in scan.grid {
            if !IsInteger(id) || id < 0 || (id && !canonical.Has(id))
                return 0
            if occupied.Has(cell) ? id != occupied[cell] : id != 0
                return 0
            mapped := id ? canonical[id] : 0
            topology .= mapped ",", key .= mapped ","
        }
        return {key: key, topology: topology, colors: colors}
    }

    QuantizedColor(color) {
        return Format("{:X}{:X}{:X}", ((color >> 16) & 255) // 32,
            ((color >> 8) & 255) // 32, (color & 255) // 32)
    }

    SameBoard(a, b) {
        if !IsObject(a) || !IsObject(b) || a.topology != b.topology
            return false
        if a.key = b.key
            return true
        ; Small color changes can cross a quantization boundary during glow
        ; animation. Compare against the saved anchor, never a drifting average.
        tolerance := this.App.S.HasOwnProp("ScanTol") ? Max(8, Min(40, this.App.S.ScanTol)) : 24
        for index, color in a.colors {
            previous := b.colors[index]
            if Max(Abs(((color >> 16) & 255) - ((previous >> 16) & 255)),
                Abs(((color >> 8) & 255) - ((previous >> 8) & 255)),
                Abs((color & 255) - (previous & 255))) > tolerance
                return false
        }
        return true
    }
}

