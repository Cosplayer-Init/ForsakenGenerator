# Forsaken Generator

Close the running copy, then open **ForsakenGenerator.ahk** with AutoHotkey **v2**. Keep **ForsakenGenerator.ini** beside it to preserve your settings and calibration. This folder and the ZIP contain the same current version.

The mouse now glides directly from a finished endpoint to the next starting dot. It no longer visits the top-left corner for scans or path checks. The button is released during transfers.

## Setup

1. Open a fresh, unconnected **7 × 7 puzzle**. Keep the game window at the same size and position.
2. If the saved coordinates do not fit, choose **Settings → Calibrate grid**, hover the top-left **cell center** and press **F6**, then hover the bottom-right **cell center** and press **F7**. The coordinate fields also accept seven individual centers per axis.
3. Activate the game and press **F9** to bind its window.
4. Press **F4** for a preview and check the endpoints in **Scan Graph**. Press **F3** to scan, solve, and draw.

**F5** stops input and turns off both automatic options. **Esc** does the same while running or watching. **F10** shows or hides the panel. Closing the panel exits the script.

## Automatic options

The Main tab has two independent switches. They take effect immediately and are saved.

- **Auto scan to graph:** checks every second and updates Scan Graph when a fresh puzzle is detected. It shows endpoint positions and colors; solution lines appear after a preview or completion run.
- **Auto complete:** checks every second and solves a detected puzzle without F3. It completes only while the bound game is active and your physical left mouse button is released. It does not activate another window automatically.

Enabling Auto Complete hides the panel so it cannot cover the puzzle. A saved Auto Complete session also starts with the panel hidden. Use **F10** to show it, and move it clear of the board if you want to watch Scan Graph while automatic options remain enabled. Auto Scan alone keeps the panel visible; move it beside the board or hide it with F10. Polling pauses while another window covers a cell, another app is active, or calibration is underway.

Automatic detection confirms two stable captures, then rechecks the board before drawing. Each detected puzzle is attempted once. A failed attempt waits for a changed puzzle or for the old board to disappear for two polls; it does not repeatedly click the same board. Use F3 for an intentional manual retry, or turn the automatic options off and on to rearm them.

## Speed

Select a preset in Settings, then click **Save settings**.

| Preset | Drag per cell | Mouse-down hold | End hold | First-drag check |
| --- | ---: | ---: | ---: | --- |
| Balanced | 44 ms | 100 ms | 45 ms | Up to 150 ms |
| Fast | 34 ms | 90 ms | 40 ms | Up to 130 ms |
| Careful | 65 ms | 140 ms | 65 ms | Up to 240 ms |
| Lightning Fast | 12 ms | 20 ms | 8 ms | Checked after the whole pass |

Balanced, Fast, and Careful confirm that each starting drag took hold, check its drawn cells or lines, and retry more slowly with the alternate Input/Event method when needed.

**Lightning Fast** bypasses the ordinary minimum timings. It uses a 10 ms starting settle, one scan frame for manual runs, no starting delay, short direct transfers, and one drawing pass without slower retries. It retains stop, focus, cursor-position, and board-presence checks. It checks all paths after drawing; if the game closes the puzzle immediately, it reports the pass as unconfirmed rather than clicking old coordinates again.

Lightning Fast targets roughly **two seconds of drawing**, rather than a guaranteed total from puzzle appearance. Timed tests with simulated input drew seven full row paths in about **1.2 seconds**, and a 24-pair board in about **1.9 seconds**. Detection can add up to a second, and scanning, solving, system load, and the game's own input handling add time. Short holds and rapid movement can miss input in a slower game. Choose Fast or Balanced if Lightning Fast is unreliable.

Settings also include color tolerances, sample radius, empty brightness, stable scan frames, solver time limit, pixel capture, mouse-input mode, and optional full-board coverage. **Normal** capture reads a snapshot efficiently; **Alt** and **Slow** are compatibility modes. Unsaved preset changes do not affect an automatic run.

## Troubleshooting

- **Wrong or missing endpoints:** recalibrate. Raise endpoint color tolerance slightly for differently shaded copies of the same color; lower it for merged colors. A fresh scan requires exactly two endpoints per detected color.
- **No drag starts:** try Balanced with Input mouse mode, or Careful. Close other copies of the macro.
- **Empty cells look colored:** hover a clear empty cell and press F8 to save its RGB color; adjust empty brightness if needed.
- **Automatic options stay paused:** bind the active game with F9, keep the board visible, and move or hide the panel. F5 and Esc disable automatic options until you enable them again.
- **No solution:** check the graph and full-board coverage option. Harder puzzles can reach the solver limit; no partial solution is drawn.

The macro checks visible drawing rather than the game's internal completion state. Tests covered both 32-bit and 64-bit AutoHotkey, scanning an owned test board, solver behavior, settings migration, direct transfers, simulated click failures and cancellation, automatic polling, obstruction, and timing. **Live gameplay and native input delivery were not verified in this execution desktop.**

## Implementation references

Capture uses RGB values as specified by the [AutoHotkey PixelGetColor documentation](https://www.autohotkey.com/docs/v2/lib/PixelGetColor.htm). Lightning's short waits use a high-resolution Windows timer when available, with a fallback to ordinary waits; see [CreateWaitableTimerExW](https://learn.microsoft.com/en-us/windows/win32/api/synchapi/nf-synchapi-createwaitabletimerexw) and [SetWaitableTimer](https://learn.microsoft.com/en-us/windows/win32/api/synchapi/nf-synchapi-setwaitabletimer).
